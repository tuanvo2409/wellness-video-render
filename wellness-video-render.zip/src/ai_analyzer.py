# Call DeepSeek API to extract keywords
