# Entry point

if __name__ == '__main__':
    print('Wellness Video Render Pipeline')
