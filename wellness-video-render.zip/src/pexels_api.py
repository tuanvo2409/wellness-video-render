# Call Pexels API to fetch videos
