# Call Replicate API to validate videos
