# Parse SRT subtitles
