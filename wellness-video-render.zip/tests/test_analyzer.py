def test_analyzer():
    assert True
