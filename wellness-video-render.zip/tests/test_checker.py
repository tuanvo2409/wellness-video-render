def test_checker():
    assert True
