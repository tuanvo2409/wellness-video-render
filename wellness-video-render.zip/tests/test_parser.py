def test_parser():
    assert True
