def test_pipeline():
    assert True
